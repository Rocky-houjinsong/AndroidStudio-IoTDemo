package shj.zjxu.com.ui.main.message;

import shj.zjxu.com.base.BaseView;

public interface MessageView extends BaseView {
}
