package shj.zjxu.com.entity;

public class DeviceDetailEntity {
}
