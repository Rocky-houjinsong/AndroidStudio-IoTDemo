package shj.zjxu.com.ui.main.scene;

import javax.inject.Inject;

import shj.zjxu.com.base.BasePresenter;

public class ScenePresenter extends BasePresenter<SceneView>{
    @Inject

    public ScenePresenter() {
    }
}
