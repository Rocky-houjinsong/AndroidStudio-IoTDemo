package shj.zjxu.com.base;

public interface BaseView {
}
