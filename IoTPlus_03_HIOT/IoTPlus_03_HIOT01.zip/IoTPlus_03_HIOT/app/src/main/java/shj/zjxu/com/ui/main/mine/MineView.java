package shj.zjxu.com.ui.main.mine;

import shj.zjxu.com.base.BaseView;

public interface MineView extends BaseView {
}
