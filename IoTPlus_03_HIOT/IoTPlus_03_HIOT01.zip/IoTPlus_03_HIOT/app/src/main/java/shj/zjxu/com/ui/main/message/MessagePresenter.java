package shj.zjxu.com.ui.main.message;

import javax.inject.Inject;

import shj.zjxu.com.base.BasePresenter;

public class MessagePresenter extends BasePresenter<MessageView> {
    @Inject
    public MessagePresenter(){}

}
