package shj.zjxu.com.ui.main;

import shj.zjxu.com.base.BaseView;

public interface MainView extends BaseView {
    void showToast(String s);
}
