package shj.zjxu.com.ui.main.scene;

import shj.zjxu.com.base.BaseView;

public interface SceneView extends BaseView {
}
