package shj.zjxu.com.ui.main.mine;

import javax.inject.Inject;

import shj.zjxu.com.base.BasePresenter;

public class MinePresenter extends BasePresenter {
    @Inject
//这里 少了东西；现在补齐了
    public MinePresenter() {
    }
}

// 第一次使用 是 无意义的，单纯的样子货；第二次 使用是 登陆测试，在MainActivity的 继承和接口中做出响相应的替换
